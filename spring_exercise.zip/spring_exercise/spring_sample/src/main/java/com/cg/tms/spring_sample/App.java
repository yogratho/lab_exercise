package com.cg.tms.spring_sample;

import com.cg.tms.customerservice.CustomerService;
import com.cg.tms.customerservice.CustomerServiceImpl;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        
    	
    	CustomerService customerService=new CustomerServiceImpl();
       System.out.println(customerService.finalAll().get(0).getFirstName());
    }
}
