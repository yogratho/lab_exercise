package com.cg.tms.repository;

import java.util.List;

import com.cg.tms.spring_sample.Customer;

public interface ICustomerRepository {

	List<Customer> findAll();

}