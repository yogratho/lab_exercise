package com.cg.tms.customerservice;

import java.util.List;

import com.cg.tms.repository.CustomerRepositoryImpl;
import com.cg.tms.repository.ICustomerRepository;
import com.cg.tms.spring_sample.Customer;

public class CustomerServiceImpl implements CustomerService {
	
	private ICustomerRepository customerRepository=new CustomerRepositoryImpl();
	public List<Customer> finalAll()
	{
		return customerRepository.findAll();
	}

}
