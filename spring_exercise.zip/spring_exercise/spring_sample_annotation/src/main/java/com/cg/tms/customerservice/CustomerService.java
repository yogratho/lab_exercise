package com.cg.tms.customerservice;

import java.util.List;

import com.cg.tms.dto.Customer;

public interface CustomerService {

	List<Customer> finalAll();

}