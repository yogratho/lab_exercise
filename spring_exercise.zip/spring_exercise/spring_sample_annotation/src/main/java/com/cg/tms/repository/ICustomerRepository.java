package com.cg.tms.repository;

import java.util.List;

import com.cg.tms.dto.Customer;

public interface ICustomerRepository {

	List<Customer> findAll();

}