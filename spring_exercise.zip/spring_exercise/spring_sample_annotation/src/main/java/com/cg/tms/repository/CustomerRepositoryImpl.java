package com.cg.tms.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.tms.dto.Customer;

@Repository("customerRepository")
public class CustomerRepositoryImpl implements ICustomerRepository {
	
	public List<Customer> findAll()
	{
		List<Customer> customers=new ArrayList<Customer>();
		Customer customer=new Customer();
		customer.setFirstName("Yogendra Singh");
		customer.setLasttName("Rathore");
		customers.add(customer);
		
		return customers;
	}

}
