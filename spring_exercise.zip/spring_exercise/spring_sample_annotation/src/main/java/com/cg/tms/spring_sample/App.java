package com.cg.tms.spring_sample;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.tms.customerservice.CustomerService;
import com.cg.tms.customerservice.CustomerServiceImpl;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	ApplicationContext applicationContext=new ClassPathXmlApplicationContext("applicationContext.xml");
    	CustomerService customerService=applicationContext.getBean("customerService", CustomerService.class);
    	System.out.println("Hello!!!");
    	System.out.println(customerService.finalAll().get(0).getFirstName());
    	
    	
      
    }
}
