package com.cg.tms.customerservice;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.tms.dto.Customer;
import com.cg.tms.repository.ICustomerRepository;

@Service("customerService")
public class CustomerServiceImpl implements CustomerService {
	//@Autowired
	private ICustomerRepository customerRepository;

	public ICustomerRepository getCustomerRepository() {
		System.out.println("hellaaaaa");
		return customerRepository;
	}
	@Autowired
	public void setCustomerRepository(ICustomerRepository customerRepository) {
		this.customerRepository = customerRepository;
	}

	public List<Customer> finalAll()
	{
		return customerRepository.findAll();
	}

}
