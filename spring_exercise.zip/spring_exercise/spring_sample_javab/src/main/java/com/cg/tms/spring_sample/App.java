package com.cg.tms.spring_sample;

import java.applet.AppletContext;

import org.omg.CORBA.portable.ApplicationException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;

import com.cg.tms.customerservice.CustomerService;
import com.cg.tms.customerservice.CustomerServiceImpl;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        
    	
    	ApplicationContext applicationContext=new ClassPathXmlApplicationContext("springDemo.xml");
    	CustomerService customerService=applicationContext.getBean("customerService", CustomerService.class);
    	System.out.println("Hello!!!");
    	System.out.println(customerService.finalAll().get(0).getFirstName());
    	
//    	 Customer customer = (Customer) applicationContext.getBean("customer");
//         System.out.println("Name : " + customer.getFirstName());
//         System.out.println("Age : " + customer.getLasttName() );
    }
}
