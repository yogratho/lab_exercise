package com.cg.tms.spring_sample;

import org.springframework.beans.factory.annotation.Required;

public class Customer {
	
	
	private String firstName;
	private String lasttName;
	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLasttName() {
		return lasttName;
	}

	public void setLasttName(String lasttName) {
		this.lasttName = lasttName;
	}

}
