package com.cg.tms.customerservice;

import java.util.List;

import com.cg.tms.repository.CustomerRepositoryImpl;
import com.cg.tms.repository.ICustomerRepository;
import com.cg.tms.spring_sample.Customer;

public class CustomerServiceImpl implements CustomerService {
	
	private ICustomerRepository customerRepository;

//	public CustomerServiceImpl() {
//		
//		
//	}
//	
	
	public CustomerServiceImpl(ICustomerRepository customerRepository) {
		
		this.customerRepository = customerRepository;
	}

	public List<Customer> finalAll()
	{
		return customerRepository.findAll();
	}

	public void setCustomerRepository(ICustomerRepository customerRepository) {
		this.customerRepository = customerRepository;
	}

}
