package com.cg.tms.repository;

import java.util.ArrayList;
import java.util.List;

import com.cg.tms.spring_sample.Customer;

public class CustomerRepositoryImpl implements ICustomerRepository {
	
	public List<Customer> findAll()
	{
		List<Customer> customers=new ArrayList<Customer>();
		Customer customer=new Customer();
		customer.setFirstName("Vishal");
		customer.setLasttName("Rathore");
		customers.add(customer);
		
		return customers;
	}

}
