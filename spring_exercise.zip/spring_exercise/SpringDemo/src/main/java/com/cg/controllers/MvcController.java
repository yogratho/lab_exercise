package com.cg.controllers;

import javax.security.auth.message.callback.PrivateKeyCallback.Request;
import javax.servlet.http.HttpServletResponse;

import org.apache.catalina.servlet4preview.http.HttpServletRequest;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MvcController {
	@RequestMapping("add")
	public ModelAndView add(@RequestParam("varOne") int first,@RequestParam("varTwo") int second )
	{
//		int first=Integer.parseInt(request.getParameter("varOne"));
//		int second=Integer.parseInt(request.getParameter("varTwo"));
		int three=first+second;
		
		ModelAndView view=new ModelAndView();
		view.setViewName("display.jsp");
		view.addObject("result", three);
		
		
		return view;
	}
}
