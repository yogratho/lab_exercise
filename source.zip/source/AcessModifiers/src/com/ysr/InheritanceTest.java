package com.ysr;

public class InheritanceTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		InheritanceSub ins=new InheritanceSub(1,"Yogendra","Jee with cloud");
		System.out.println(ins.getId());
		System.out.println(ins.getName());
		System.out.println(ins.getDepartment());
	
//	void add() {
//		System.out.println("hello");
//	}
//	int add() {
//		return 55;
//	}
	}

}
