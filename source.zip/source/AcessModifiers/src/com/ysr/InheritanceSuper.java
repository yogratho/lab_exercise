package com.ysr;

public class InheritanceSuper {
	protected int id;
	protected String name;
	
	
	public InheritanceSuper(int id, String name) {
		
		this.id = id;
		this.name = name;
		System.out.println("Super Class");
	}
	protected int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	protected String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

}
