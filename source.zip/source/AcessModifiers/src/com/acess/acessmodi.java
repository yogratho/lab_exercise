package com.acess;
 class acessmodifier {
	
	public void methodOne()
	{
		System.out.println("MEthod 1");
	}
	private void methodTwo()
	{
		System.out.println("MEthod 2");
	}
	protected void methodThree()
	{
		System.out.println("MEthod 3");
	}
	void methodFour()
	{
		System.out.println("MEthod 4");
	}

}

 
