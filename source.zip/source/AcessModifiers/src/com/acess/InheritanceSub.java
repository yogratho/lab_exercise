package com.acess;

import com.ysr.InheritanceSuper;

class InheritanceSub extends InheritanceSuper{

	private String Department;

	public InheritanceSub(int id, String name,String dep) {
		super(id, name);
		Department=dep;
		System.out.println("Sub Class");
		// TODO Auto-generated constructor stub
	}

	public String getDepartment() {
		return Department;
	}

	public void setDepartment(String department) {
		
		
		Department = department;
	}
	

	
	
}
