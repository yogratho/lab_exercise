package com.cg.datetime;

import java.time.LocalDate;
import java.time.Month;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

public class DateAndTimeSample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LocalDate date=LocalDate.now();
		System.out.println("Today's Date is:"+date);
		Month month = date.getMonth(); 
	    int day = date.getDayOfMonth(); 
	     
	    System.out.println("Month : "+month+" day : "+ 
	                        day);
	    
	    DateTimeFormatter format=DateTimeFormatter.ofPattern("yyyy-dd-MM");
	    String formattedCurrentDate = date.format(format);
	    System.out.println(formattedCurrentDate);
	    
	   ZonedDateTime zone=ZonedDateTime.now();
	   System.out.println(zone.getZone());
	
	}

}
