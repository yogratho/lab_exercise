package com.cg.exceptionsample;
  class Aray
{
	public int name() {
		 
		System.out.println("hella");
		try
		{
			System.out.println(7/0);
			return 1;
		}
		catch(Exception e)
		{
			return 2;
		}
		finally {
			return 3;
		}
	 }
	}

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Aray a=new Aray();
		Aray b=a;
		System.out.println(a==b);
		System.out.println(a.equals(b));
		System.out.println(a.name());
		
	}

}
