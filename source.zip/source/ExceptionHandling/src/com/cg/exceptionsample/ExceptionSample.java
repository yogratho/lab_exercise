package com.cg.exceptionsample;

import java.util.Scanner;
class NewException extends Exception implements AutoCloseable
{
NewException(String str)	
{
System.out.println("Hello "+str+" from NewException");	
}

@Override
public void close() throws Exception {
	// TODO Auto-generated method stub
	System.out.println("hello");
	throw new NewException("hghjgaj");
	
}

}

public class ExceptionSample {

	public static void main(String[] args) throws NewException,Exception {
		Scanner sc=new Scanner(System.in);
		
		try(NewException ne=new NewException("Yogendra"))
		{
			
		}
		
			
		
		
	}
}
