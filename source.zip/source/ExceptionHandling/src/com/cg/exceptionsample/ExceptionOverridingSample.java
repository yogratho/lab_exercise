package com.cg.exceptionsample;

import java.util.Scanner;

public class ExceptionOverridingSample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		Scanner sc=new Scanner(System.in);
		System.out.println("enter name");
		String name=sc.nextLine();
		System.out.println(name);
		

	}

}
