package com.cg.jpa.JpaDemo;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Skill {

@Id
private String employeeId;
@Override
public String toString() {
	return "Skill [employeeId=" + employeeId + ", skill=" + skill + "]";
}
private String skill;
public String getEmployeeId() {
	return employeeId;
}
public void setEmployeeId(String employeeId) {
	this.employeeId = employeeId;
}
public String getSkill() {
	return skill;
}
public void setSkill(String skill) {
	this.skill = skill;
}
}
