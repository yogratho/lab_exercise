package com.ysr.abstraction;

public class String {

	public static void main(java.lang.String[] args) {
		// TODO Auto-generated method stub
System.out.println("capgemini");

	}

}
