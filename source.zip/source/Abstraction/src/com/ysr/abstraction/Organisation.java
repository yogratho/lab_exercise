package com.ysr.abstraction;

abstract class Organisation
{
	private int id;
	private String name;
	private String field;
	
	public Organisation(int id, String name, String field) {
	
		this.id = id;
		this.name = name;
		this.field = field;
	}
	
	public void setId(int id) {
		
	}
	
	public void setName(String name) {
		
	}
	
	public void setField(String field) {}
		
	
	
	
	
	

}
