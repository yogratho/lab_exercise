package com.ysr.abstraction;

public class overloadingtest {
	
	static  int add(int a,int b) { return 6;}
	static String add(int a ,int b) {return "ysr";}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
