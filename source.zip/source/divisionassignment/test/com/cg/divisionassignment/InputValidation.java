package com.cg.divisionassignment;

import static org.junit.Assert.*;

import org.junit.Test;

public class InputValidation {

	@Test
	public void secondNumberZeroTest() {
		assertEquals(true, DivisionTest.divisionTest(1,0));
	}
	@Test
	public void resultGreaterThanOne()
	{
		assertEquals(true, DivisionTest.divisionTest(1,111));
	}
	
}
