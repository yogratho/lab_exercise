package com.cg.divisionassignment;

public class DivisionSample {
	
	public float divideOperation(float first,float second) throws ArithmeticException
	{
		if(first==0 || second==0)
			throw new ArithmeticException("Divide by zero is not allowed");
		else if(first>=second)
			return first/second;
		else
			return second/first;
	}

}
