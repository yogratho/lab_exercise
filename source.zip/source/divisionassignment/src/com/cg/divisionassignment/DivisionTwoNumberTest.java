package com.cg.divisionassignment;

import java.util.Scanner;

public class DivisionTwoNumberTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		do
		{
			
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter first number:");
		int firstNumber=scanner.nextInt();
		System.out.println("Enter second number:");
			
		int secondNumber=scanner.nextInt();
		DivisionSample division=new DivisionSample();
		try
		{
		
			float results=division.divideOperation(firstNumber, secondNumber);
			System.out.println(results);
		}
		catch(ArithmeticException e)
		{
			System.out.println(e.getMessage());
		}
		System.out.println("Do you want to continue!!!!!!!");
		System.out.println("1.continue\n2.exit");
		byte choice=scanner.nextByte();
		
		if(choice==2)
			{
			System.out.println("Thanks!!");
			System.exit(1);
			
			}
		}while(true);

	}

}
