package com.cg.divisionassignment;

import java.util.Scanner;

public class DivisionTest {
public static boolean divisionTest(int first,int second)
{
	
//	System.out.println("Enter first number:");
//	int firstNumber=scanner.nextInt();
//	System.out.println("Enter second number:");
		
	//int secondNumber=scanner.nextInt();
	if(first==0 && second==0 )
	{
		System.out.println("Please enter correct digits");
		return false;
	}
	else if(first>=second)
	{
		try
		{
			if(second==0)
				throw new ArithmeticException("Sorry / by 0 is not allowed");
			float result=first/second;
			System.out.println(result);
		}
		catch(ArithmeticException e)
		{
			System.err.println(e.getMessage());
		}
		
		return true;
	}
	else if(second>=first)
	{
		try
		{
			if(first==0)
				throw new ArithmeticException("Sorry / by 0 is not allowed");
			float results=second/first;
			System.out.println(results);
		}
		catch(ArithmeticException e)
		{
			System.err.println(e.getMessage());
		}
		
		return true;
	}
	else
		return false;
	
	
	
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		do
		{
			
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter first number:");
		int firstNumber=scanner.nextInt();
		System.out.println("Enter second number:");
			
		int secondNumber=scanner.nextInt();
		divisionTest(firstNumber, secondNumber);
		System.out.println("Do you want to continue!!!!!!!");
		System.out.println("1.continue\n2.exit");
		byte choice=scanner.nextByte();
		
		if(choice==2)
			{
			System.out.println("Thanks!!");
			System.exit(1);
			
			}
		}while(true);
}
}
