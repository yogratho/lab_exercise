package com.cg.junit;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.cg.junit.service.IAtmService;
import com.cg.junit.service.IAtmServiceImpl;

class TestAtmServices {
	 
	IAtmService iAtmServiceImpl=new IAtmServiceImpl();
	@Test
	public void testWithdrawl()
	{
		assertEquals("Error", iAtmServiceImpl.withdrawl("123456789", ""));
	}
	@Test
	public void testDeposit()
	{
		assertEquals("15000", iAtmServiceImpl.deposit("123456789", "5000"));
		
	}
	@Test
	public void negativeWithdrawlAmount()
	{
		assertEquals("Error", iAtmServiceImpl.deposit("123456789", "-123"));
	}

}
