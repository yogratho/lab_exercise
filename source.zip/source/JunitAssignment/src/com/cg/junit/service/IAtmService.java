package com.cg.junit.service;

public interface IAtmService {
		
	String ACCNO="123456789";
	
	
	public String withdrawl(String accNo,String amount);
	
	public String deposit(String accNo,String amount);
}