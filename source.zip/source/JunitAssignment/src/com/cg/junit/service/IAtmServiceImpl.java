package com.cg.junit.service;

public class IAtmServiceImpl implements IAtmService {
	long updatedBalance = 10000;

	public String withdrawl(String accNo, String amount) {
		if (IAtmService.ACCNO.equals(accNo) && !(amount.isEmpty())) {
			long balance = Integer.parseInt(amount);
			updatedBalance = updatedBalance - balance;
		}
		
		else return "Error";
			return updatedBalance + "";
	}

	public String deposit(String accNo, String amount) {
		long balace = Integer.parseInt(amount);
		
		if(balace<0)
			return "Error";
		else if (IAtmService.ACCNO.equals(accNo) && !(amount.isEmpty())) {
			long balance = Integer.parseInt(amount);
			updatedBalance = updatedBalance + balance;
		}
		else return "Error";
		return updatedBalance + "";

	}
}
