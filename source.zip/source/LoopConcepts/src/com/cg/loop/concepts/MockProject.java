package com.cg.loop.concepts;

import java.util.Scanner;

public class MockProject {
	public static  void checkPalindromeDigit(int num)
	{
		int dummy=num;
		int result=0,remainder;
		while(dummy>0)
		{
			 remainder=dummy%10;
			 result=result*10+remainder;
			dummy=dummy/10;
		}
		if(num==result)
			System.out.println("Palindrome");
		else
			System.out.println("Not a Palindrome");
		
	}
	public static void checkPalindromeString(String str)
	{
		boolean check=false;
	
		for(int i=0;i<(str.length()-1)/2;i++)
		{
			if(str.charAt(i)==str.charAt(str.length()-1-i))
				check=true;
			else
			{
			System.out.println("String is Not Palindrome");
			System.exit(1);
			}
		
		}
		
		if(check==true)
			System.out.println("String is Palindrome");
		
		
	}
	public static boolean isArmstrong(int number)
	{
		int dummy=number,result=0,remainder;
		while(dummy>0)
		{
			remainder=dummy%10;
			result=result+(remainder*remainder*remainder);
			dummy/=10;
		}
		if(result==number)
			return true;
		return false;
	}
	public static void checkArmstrong(int min,int max)
	{
		for(int i=min;i<=max;i++)
		{
			if(isArmstrong(i))
				System.out.println(i+"is a Armstrong Number");
			else
				continue;
			
		}
	}
	public static void printPattern(int number)
	{
		for(int i=1;i<=number;i++)
		{
			for(int j=number;j>i;j--)
				System.out.print(" ");
			for(int k=i;k>=1;k--)
				System.out.print(k);
			if(i!=1)
			{
				for(int l=1;l<i;l++)
					System.out.print(l+1);
				
			}
			System.out.println("");
		}
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int chances=0;
		Scanner scanner=new Scanner(System.in);
		do
		{
			System.out.println("1.Check Plaindrome(Use Digits)");
			System.out.println("2.Check Plaindrome(Use Alphabets)");
			System.out.println("3.Print Armstrong Number");
			System.out.println("4.Pattern Printing");
			int choice = scanner.nextInt();
			switch(choice)
			{
			case 1:System.out.println("Enter the number:");
				   int number=scanner.nextInt();
				   checkPalindromeDigit(number);
				   break;
		
			case 2: System.out.println("Enter the String:");
			        String str=scanner.next();
			        checkPalindromeString(str);
			        break;
			
			case 3:checkArmstrong(1,500);
					break;
			
			case 4:System.out.println("Enter the number:");
			       int size=scanner.nextInt();
			       printPattern(size);
			       break;
			default:System.out.println("Do you want to continue");
					chances++;
					
					if(chances==3)
						System.exit(1);
					else
						continue;
			
			}
			
		}while(true);

	}

}
