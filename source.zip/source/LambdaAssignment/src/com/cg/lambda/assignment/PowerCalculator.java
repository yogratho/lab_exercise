package com.cg.lambda.assignment;

public interface PowerCalculator {
	 double computePower(int x,int y);

}
