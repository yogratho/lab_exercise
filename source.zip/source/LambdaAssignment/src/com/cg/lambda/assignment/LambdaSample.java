package com.cg.lambda.assignment;

public class LambdaSample {

	public static void main(String[] args) {
		
		//lambda assignment question 1
		PowerCalculator myLambda=(x,y)->Math.pow(x,y);
		
		double result=myLambda.computePower(2, 3);
		System.out.println("Result="+result);
		
		//lambda assignment question 2
		StringFormatter formatter=(string)->string.replace("", " ").trim();
		
		String test=formatter.stringFormat("Yogendra");
		System.out.println("String After formatting="+test);
		
		//lambda assignment question 3
		
		
		UserNamePassAuthenticate authenticate=(userName,password)->{
			
		if(userName.equals(UserNamePassAuthenticate.userName)&& password.equals(UserNamePassAuthenticate.password))
			return true;
		else 
			return false;
		};
		boolean response=authenticate.userAuthentication("Yogendra Singh", "yogi");
		if(response==true)
			System.out.println("User is authenticated");
		else
			System.out.println("User is not authenticated"); 
		
		
		//lambda assignment question 4
		MethodReferenceSample refer=new MethodReferenceSample();
		MethodReference meReference=refer::displayHello();
		
		
		
	}

}
