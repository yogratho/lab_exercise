package com.cg.lambda.assignment;

public interface UserNamePassAuthenticate {
	
	String userName="Yogendra Singh";
	String password="yogi";
	boolean userAuthentication(String userName,String password);

}
