package com.cg.lambda.assignment;

public interface StringFormatter {
	
	String stringFormat(String sample);

}
