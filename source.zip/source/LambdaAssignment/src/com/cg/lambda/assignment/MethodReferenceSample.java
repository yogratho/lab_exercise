package com.cg.lambda.assignment;
interface MethodReference
{
void display();	
}
public class MethodReferenceSample {
	public void displayHello()
	{
		System.out.println("Hello from display hello function");
	}
	

}
