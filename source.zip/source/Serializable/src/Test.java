
import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set; 
  
class Demo implements java.io.Serializable 
{ 
    public int a; 
    public   String b; 
  
    // Default constructor 
    public Demo(int a, String b) 
    { 
        this.a = a; 
        this.b = b; 
    } 
  
} 
  
class Test 
{ 
    public static void main(String[] args) throws SQLException 
    {    
    	
        Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "system");
        System.out.println(con);
        Set set=new HashSet();
        set.add("b");
        set.add("b");
        System.out.println(set);
    Collection collection=new HashSet();
    Collections.so
    		
    }}