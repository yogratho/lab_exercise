package com.hotel.server;

import com.hotel.client.INonVeg;
import com.hotel.client.IVeg;

public class HotelKitchen implements IVeg,INonVeg {
	
	@Override
	public void vegSnacks() {
		// TODO Auto-generated method stub
		//System.out.println(IVeg.s);
		System.out.println("------------------------------Menu for Veg Snacks------------------------------");
		System.out.println("1.Pizza\n2.Chole Bature\n3.Bada Pav");
	}
	@Override
	public void vegMainCourse() {
		// TODO Auto-generated method stub
		//System.out.println(IVeg.s);
		System.out.println("------------------------------Menu for Veg Main Course------------------------------");
		System.out.println("1.Butter Paneer\n2.Kadai Paneer\n3.Thali");

	}
@Override
public void nonVegSnacks() {
	// TODO Auto-generated method stub
	//System.out.println(INonVeg.s);
	System.out.println("------------------------------Menu for Non Veg Snacks------------------------------");
	System.out.println("1.Chicken Burger\n2.Chicken Tikka\n3.Kabab");

	
}
@Override
public void nonVegMainCourse() {
	// TODO Auto-generated method stub
	//System.out.println(INonVeg.s);
	//System.out.println("------------------------------Menu for Non Veg Main Course------------------------------");
	System.out.println("1.Chicken Burger\n2.Chicken Tikka\n3.Kabab");
}
}
