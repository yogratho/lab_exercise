package com.hotel.ui;

import com.hotel.client.IVeg;
import com.hotel.server.HotelKitchen;

public class VegClientTest extends HotelKitchen{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		IVeg iv=new HotelKitchen();
		iv.vegSnacks();
		iv.vegMainCourse();
	
	}

}
