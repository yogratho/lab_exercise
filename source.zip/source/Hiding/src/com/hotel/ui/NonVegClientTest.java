package com.hotel.ui;

import com.hotel.client.INonVeg;
import com.hotel.server.HotelKitchen;

public class NonVegClientTest extends HotelKitchen  {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		INonVeg iv=new HotelKitchen();
		iv.vegSnacks();
		iv.vegMainCourse();
		iv.nonVegSnacks();
		iv.nonVegMainCourse();

	}

}
