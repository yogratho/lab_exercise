package com.hotel.client;

public interface IVeg {
	 String serve="We Serve you Only Veg";
	 void vegSnacks();
	 void vegMainCourse();
	

}
