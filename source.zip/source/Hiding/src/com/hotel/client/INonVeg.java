package com.hotel.client;

public interface INonVeg {
	 String serve="We Serve you Both Veg and Non veg";
	 void vegSnacks();
	 void vegMainCourse();
	 void nonVegSnacks();
	 void nonVegMainCourse();

}
