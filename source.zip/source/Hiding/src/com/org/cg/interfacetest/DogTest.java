package com.org.cg.interfacetest;

public class DogTest implements IAnimal{
	public void talk()
	{
		System.out.println("Bhau Bhau");
	}
	public void food()
	{
		System.out.println("Meat");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DogTest dt=new DogTest();
		dt.talk();
		dt.food();
	}

}
