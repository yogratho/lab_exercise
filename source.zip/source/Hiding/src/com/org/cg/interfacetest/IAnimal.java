package com.org.cg.interfacetest;

public  interface IAnimal extends ILivingBeings {

	 
		abstract public void food();
			
			
	
	
	}
