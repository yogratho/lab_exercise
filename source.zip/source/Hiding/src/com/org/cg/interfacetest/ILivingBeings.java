package com.org.cg.interfacetest;

public interface ILivingBeings {
	
	void talk();

}
