package com.org.cg.interfacetest;

public class HawellsChild extends Hawells {

	public void jack()
	{
		System.out.println("Now Hawells child also implemented jack part");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		IStandardOrg hc=new HawellsChild();
		hc.jack();
		hc.usb();
	}

}
