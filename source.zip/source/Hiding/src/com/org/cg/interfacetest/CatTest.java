package com.org.cg.interfacetest;

public class CatTest implements IAnimal{
	public void talk()
	{
		System.out.println("Meeew Meeew");
	}
	public void food()
	{
		System.out.println("Rat");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CatTest ct=new CatTest();
		ct.talk();
		ct.food();
	}

}
