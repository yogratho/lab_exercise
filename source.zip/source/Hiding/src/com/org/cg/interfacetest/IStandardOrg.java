package com.org.cg.interfacetest;

public interface IStandardOrg {
	float standard_value = 3.5f;
	String standard_string = "ISO";
	void usb();
	void jack();

}
