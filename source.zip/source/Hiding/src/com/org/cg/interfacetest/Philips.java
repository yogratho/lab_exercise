package com.org.cg.interfacetest;

public class Philips implements IStandardOrg {
	public void usb()
	{
		System.out.println("Philips implemented USB part");
	}
	 public  void jack()
	 {
			System.out.println("Philips implemented jack part");

	 }
	 public static void main(String[] args) {
		Philips p=new Philips();
		System.out.println(IStandardOrg.a1+"\n"+IStandardOrg.s);
		p.usb();
		p.jack();
	}

}
