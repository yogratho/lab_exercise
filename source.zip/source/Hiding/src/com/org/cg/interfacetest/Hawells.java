package com.org.cg.interfacetest;

public abstract class Hawells implements IStandardOrg {
	 public void usb()
	{
		System.out.println("Hawells implemented USB part");
	}
	 public abstract void jack();
	

}
