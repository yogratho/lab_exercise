package com.ysr.enumDemo;

public class EnumTest {
	 enum Test 
	 {
		 ysr(1),ysr2(2);
		 private int demo;
		Test(int t)
		{
		demo=t;	
		}
		 
	 }

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
