package com.hiding;

	
	
	}
public class Test {
	private int abc;
	
	Test(int x)
	{
		System.out.println(x);
		
	}
	{
		abc=1234;
		System.out.println(abc);
	}
	static
	{
		System.out.println("static");
	}
	public String toString()
	{
		String s="hello";
		return s;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Test t=new Test(323);
		System.out.println(t.toString());
	
		//public enum enumDemo {}
		for (enumDemo s : enumDemo.values())  
			System.out.println(s); 
		
		
//String s="ysr";
//String s2=s.intern();
//System.out.println(s2);
//System.out.println(s2.isEmpty());



	}}
//final class EnumTest
//{
//	
//
//public static final int id=12;
//public static final String name="ysr";
//
//
//}


