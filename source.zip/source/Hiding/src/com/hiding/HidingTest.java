package com.hiding;

public class HidingTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		bus b=new bus();
		//b.addpassenger(2);
		System.out.println(b.seats);
		VolvoBus vb=new VolvoBus();
		System.out.println(vb.seats);
		bus b2=new VolvoBus();
		System.out.println(b2.getSeats());
//		VolvoBus vb=new VolvoBus();
//		vb.addpassenger(33);

	}

}
