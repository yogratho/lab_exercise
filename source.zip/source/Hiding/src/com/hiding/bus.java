package com.hiding;

public class bus {
	protected int seats=111;
	protected int passanger=0;
	public void addpassenger(int i)
	{
		if(hasseats())
			{
			//System.out.println(this.seats);
			passanger++;
			}
		else
			System.out.println("not available");
	}
	public int getSeats()
	{
		return seats;
	}
	public boolean hasseats()
	{
		return passanger<seats;
	}
}
