package com.hiding;

public class VolvoBus extends bus{
	protected int seats=11;

}
