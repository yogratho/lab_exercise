
public class Sample {
	public String sample()
	{
				return "hello sample";
	}

}
