package com.cg.functionalinterface;

@FunctionalInterface
interface TestInterface
{
void oneMethod();
default public void display()
{
System.out.println("Hello from display!!!");	
}
default public void nameDisplay() {
	System.out.println("In nameDisplay Method");
}

}
 public class FuntionalI {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//TestInterface it=() -> System.out.println("java");
		TestInterface it=new TestInterface() {
			
			@Override
			public void oneMethod() {
				// TODO Auto-generated method stub
				System.out.println("helloooooooo");
			}
		};
		it.oneMethod();
		
		it.display();
	}

}
