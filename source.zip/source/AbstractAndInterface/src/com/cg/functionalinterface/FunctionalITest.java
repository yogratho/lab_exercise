package com.cg.functionalinterface;

interface MyInterface
{
	void show();
}
 
public class FunctionalITest {
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyInterface mi=() -> System.out.println("Hello from show");
		mi.show();
	
	}

}
