package com.cg.trainingmanagementsystem.service.impl;


import java.util.*;

import com.cg.trainingmanagementsystem.collection.TrainerStaticDatabase;
import com.cg.trainingmanagementsystem.dao.ICrudOperation;
import com.cg.trainingmanagementsystem.dao.impl.TrainerManagementDaoImpl;
import com.cg.trainingmanagementsystem.exception.ProgramException;
import com.cg.trainingmanagementsystem.service.ITrainerManagement;
import com.cg.trainingmanagementsystem.service.entity.Trainer;
import com.cg.trainingmanagementsystem.service.enumv.Skills;
import com.cg.trainingmanagementsystem.utility.DataExistenceCheck;
import com.cg.trainingmanagementsystem.utility.DatabaseEmployeeExistenceCheck;
import com.cg.trainingmanagementsystem.utility.ErrorMessages;
import com.cg.trainingmanagementsystem.utility.TrainerCredentialValidation;

/**
 * 
 */
public class TrainerManagementImpl implements ITrainerManagement {

	
	@Override
public  boolean addSkillTrainers(String trainerID,Set<String> skills) throws ProgramException
{
	boolean response=false;
	if (DatabaseEmployeeExistenceCheck.trainerExistenceCheck(trainerID)) {
	
		System.out.println(trainerID+" You possess following skills");
		ICrudOperation iCrudOperation = new TrainerManagementDaoImpl();
		iCrudOperation.getTrainerSkills(trainerID);
		Trainer trainer=new Trainer();
		trainer.setTrainerId(trainerID);
		iCrudOperation.trainerSkillAddition(trainer, skills);
		response=true;
		
		
		
		
	}
	return response;


}
	@Override
public  boolean delSkillTrainers(String trainerID,Set<String> skills) throws ProgramException
{
	boolean response=false;
	if (DatabaseEmployeeExistenceCheck.trainerExistenceCheck(trainerID)) {
		byte count=0;
		System.out.println(trainerID+" You possess following skills");
		ICrudOperation iCrudOperation = new TrainerManagementDaoImpl();
		iCrudOperation.getTrainerSkills(trainerID);
		Trainer trainer=new Trainer();
		trainer.setTrainerId(trainerID);
		
		response=true;
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter number of skills you wanted to Delete");
		try {
			count = scanner.nextByte();
		} catch (Exception e) {
			throw new ProgramException(ErrorMessages.MESSAGE4);
		}

		System.out.println("Now enter that " + count+ " skill you want to delete from the above");
		Set<String> skilllist = new HashSet<String>();
		String skill;
		for (int i = 1; i <= count; i++) 
		{
			skill = scanner.next();
			skilllist.add(skill);
		
		}
			iCrudOperation.trainerSkillDeletion(trainer, skilllist);
		response=true;
		
		
	}
	return response;


}
	@Override
	public Trainer getTrainerDetails(Trainer trainer) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public HashSet<Trainer> getAllTrainers() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean createTrainer(Trainer trainer) {
		// TODO Auto-generated method stub
		return false;
	}

}