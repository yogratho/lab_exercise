package com.cg.trainingmanagementsystem.service.enumv;

public enum Skills {
	ORACLE,JAVA,C,DBMS,PYTHON,RUBY,HTML,CSS,JAVASCRIPT,PHP,ANDROID;
	

}
