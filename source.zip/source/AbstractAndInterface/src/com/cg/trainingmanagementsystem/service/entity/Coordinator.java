package com.cg.trainingmanagementsystem.service.entity;

public class Coordinator extends Employee {
	private Center center;
	/**
	 * Default constructor
	 */
	public Coordinator() {
	}

	/**
	 * 
	 */
	

}