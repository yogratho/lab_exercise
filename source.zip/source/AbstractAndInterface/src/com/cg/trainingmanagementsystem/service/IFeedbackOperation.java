package com.cg.trainingmanagementsystem.service;

import com.cg.trainingmanagementsystem.service.entity.Feedback;
import com.cg.trainingmanagementsystem.service.entity.TrainingProgram;

public interface IFeedbackOperation {

	public Feedback viewFeedbackReport();

	public Feedback viewDefaulterList(TrainingProgram trainingProgram, Feedback feedback);

}