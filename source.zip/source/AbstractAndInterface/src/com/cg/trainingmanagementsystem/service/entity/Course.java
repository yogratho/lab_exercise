package com.cg.trainingmanagementsystem.service.entity;

public class Course {

	/**
	 * Default constructor
	 */
	public Course() {
	}

	/**
	 * 
	 */
	private String courseId;

	/**
	 * 
	 */
	private String courseName;

	/**
	 * 
	 */
	private String courseDesc;

	/**
	 * 
	 */
	private int courseCharges;



}