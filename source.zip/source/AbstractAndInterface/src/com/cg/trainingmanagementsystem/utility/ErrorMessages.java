package com.cg.trainingmanagementsystem.utility;

public class ErrorMessages {

	public static final String MESSAGE7 = "Enteres skill is already there...Please enter another ";
	public static final String MESSAGE2 = "Entered skill is not there enter another";
	public static final String MESSAGE3 = "You have no skills to delete";
	public static final String MESSAGE4="Please Enter number only";
	public static final String MESSAGE5	="Entered Id is not in proper format";
	public static final String MESSAGE6	="Trainer is not authorized";
	public static final String MESSAGE1="Entered id is not registered";
	public static final String MESSAGE8="Entered ID is not in valid format";
	public static final String MESSAGE9="Entered skill is not according to our requirement!!..Please enter again";
	public static final String MESSAGE10="Invalid Entry";
	public static final String MESSAGE11="Error!!!Something went wrong";

}
