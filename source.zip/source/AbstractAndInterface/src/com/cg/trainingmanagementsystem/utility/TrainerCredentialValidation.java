package com.cg.trainingmanagementsystem.utility;

import java.util.Iterator;
import java.util.Set;

import com.cg.trainingmanagementsystem.collection.TrainerStaticDatabase;
import com.cg.trainingmanagementsystem.exception.ProgramException;
import com.cg.trainingmanagementsystem.service.entity.Trainer;
import com.cg.trainingmanagementsystem.utility.ErrorMessages;

public class TrainerCredentialValidation 
{
	
	public static boolean trainerIdValidate(String trainerId)
	throws  ProgramException
	{
		if(trainerId.matches("[0-9]{6}IN"))
		{
			return true;
		}
		else if(trainerId.matches("[$&+,:;=?@#|'<>.-^*()%!]*")) 
		{
			throw new ProgramException(ErrorMessages.MESSAGE8);
		}
		else
		{
			throw new ProgramException(ErrorMessages.MESSAGE8);
		}
	
	}
	public static boolean trainerRegistrationCheck(String trainerId)
	{
		Set<Trainer> trainer;
		trainer=TrainerStaticDatabase.trainer;
		Iterator value = trainer.iterator();
		boolean response=false;
		while(value.hasNext())
		{
			Trainer tt=(Trainer)value.next();
			if(tt.getTrainerId().equalsIgnoreCase(trainerId))
			{
				
				response=true;
				break;
			}
		}
return response;
}
	}
	


