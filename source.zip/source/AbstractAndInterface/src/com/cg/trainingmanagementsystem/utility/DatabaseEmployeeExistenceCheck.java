package com.cg.trainingmanagementsystem.utility;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.trainingmanagementsystem.exception.ProgramException;

public class DatabaseEmployeeExistenceCheck {
	
	public static boolean trainerExistenceCheck(String trainerID) throws ProgramException
	{
		
		boolean response=false;
		Connection connection=null;
		PreparedStatement preparedStatement=null;
		try {
			connection=ConnectionDb.getConnection();
			 preparedStatement=connection.prepareStatement(DbQueries.CHECK_EXISTENCE);
			 preparedStatement.setString(1,trainerID);
				ResultSet resultSet=preparedStatement.executeQuery();
				while(resultSet.next())
				{
				if(resultSet.getString(1).equals(trainerID))
					response=true;
				}
				connection.commit();
		}
catch (SQLException e) {
			
			throw new ProgramException(ErrorMessages.MESSAGE10);
		}

return response;
	}
//	public static boolean skillExistenceCheck()
	
}
