package com.cg.trainingmanagementystem.ui;


import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;

import com.cg.trainingmanagementsystem.collection.TrainerStaticDatabase;
import com.cg.trainingmanagementsystem.exception.ProgramException;
import com.cg.trainingmanagementsystem.service.ITrainerManagement;
import com.cg.trainingmanagementsystem.service.entity.Course;
import com.cg.trainingmanagementsystem.service.entity.Feedback;
import com.cg.trainingmanagementsystem.service.entity.Trainer;
import com.cg.trainingmanagementsystem.service.enumv.Skills;
import com.cg.trainingmanagementsystem.service.impl.TrainerManagementImpl;
import com.cg.trainingmanagementsystem.utility.DataExistenceCheck;
import com.cg.trainingmanagementsystem.utility.DatabaseEmployeeExistenceCheck;
import com.cg.trainingmanagementsystem.utility.ErrorMessages;
import com.cg.trainingmanagementsystem.utility.TrainerCredentialValidation;

/**
 * 
 */
public class AdminController {

	public AdminController() {
	}

	private Trainer trainer;

	private Course course;

	private Feedback feedback;
	public static void addSkillControllers() throws  ProgramException
	{	
		byte count=0;
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter the Trainer Id:");
		String trainerId=scanner.next();
		//validating input trainer ID and taking list of skill
		if(TrainerCredentialValidation.trainerIdValidate(trainerId))
		{	
			System.out.println("List of skills We Require..Please enter only these");
			for (Skills s : Skills.values())  
				System.out.println(s);
			System.out.println("Enter number of skills you wanted to add:");
			try
				{
				count=scanner.nextByte();
				}
				catch(Exception exception)
				{
					throw new ProgramException(ErrorMessages.MESSAGE4);
				}
			 

			System.out.println("Now enter that " +count+ " skill you want to add from the above");
			Set<String> skilllist=new HashSet<String>();
			String skill;
			for(int i=1;i<=count;i++)
			{
				
				skill=scanner.next();
				//checking existence in database
				if(DataExistenceCheck.DataBaseExistenceCheck(skill))
				{
					skilllist.add(skill);
				}
					else
					throw new ProgramException(ErrorMessages.MESSAGE9);
			}

			ITrainerManagement itrainermanagement=new TrainerManagementImpl();
			if(itrainermanagement.addSkillTrainers(trainerId, skilllist))
				System.out.println("Skill is successfully added");
			else
				System.out.println("Trainer is not Registered in our Database");
		}
		else
		{
			throw new ProgramException(ErrorMessages.MESSAGE8);
		}
	}
	//funtion to delete skill of trainer
	public static void delSkillController() throws  ProgramException
	{
		Scanner scanner=new Scanner(System.in);
		ITrainerManagement itrainermanagement;
		//boolean check=false;
		System.out.println("Enter the Trainer Id:");
		String trainerId=scanner.next();
		if(TrainerCredentialValidation.trainerIdValidate(trainerId) && DatabaseEmployeeExistenceCheck.trainerExistenceCheck(trainerId) )
		{

					System.out.println(" We are fetching your skills please wait");
					itrainermanagement=	new TrainerManagementImpl();
					itrainermanagement.delSkillTrainers(trainerId, null);
				
			
			
		}
		else
		{
			throw new ProgramException(ErrorMessages.MESSAGE1);
		}
		
		
		
}
	

}