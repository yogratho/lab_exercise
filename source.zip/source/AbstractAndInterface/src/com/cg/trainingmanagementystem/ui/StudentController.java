package com.cg.trainingmanagementystem.ui;

import java.util.*;

import com.cg.trainingmanagementsystem.service.entity.Student;
import com.cg.trainingmanagementsystem.service.entity.TrainingProgram;

public class StudentController {

	public StudentController() {
	}

	private Student student;

	private TrainingProgram trainingProgram;

}