package com.cg.abstractandinterface;
class A
{
	static int a=11;
public void fun()
{
System.out.println("hello from  a");	
}
}
class B extends A
{	static int a=123;
	public  void fun()
	{
	System.out.println("hello from  b");	
	}	
}
public class OverridingTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		B bb=new B();
	bb.fun();
	}

}
