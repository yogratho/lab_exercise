package com.cg.abstractandinterface;

public class StringTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1="ysr";
		String s2="ys";
		String s3=s2+"r";
		System.out.println(s1.hashCode()==s3.hashCode());

	}

}
