package com.cg.abstractandinterface;

public interface InterfaceAndDefault {
	
	static public void fun1()
	{
		System.out.println("in fun1 static ");
		
	}
	public abstract void fun2();
	public default  void fun3()
	{
		System.out.println("fun3 default");
	}

}
