package com.cg.abstractandinterface;

public class OverloadTest {
	static int add(int a,int b)
	{
		return a+b;
	}
	static double add(int a,int b,int c)
	{
		return a+b+c;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=OverloadTest.add(2,3);
		System.out.println(a);
		double b=OverloadTest.add(2,3,4);
		System.out.println(b);
		
		
	}

}
