package com.cg.abstractandinterface;

public class InterfaceTest implements InterfaceAndDefault {
	static public void fun1()
	{
		System.out.println("in fun1 static of InterfaceTest Class ");
		
	}
	public void fun2()
	{
		System.out.println("hello from class");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		InterfaceTest it=new InterfaceTest();
		it.fun1();
		it.fun2();
	}
	

}
