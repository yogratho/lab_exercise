package com.cg.main;

import com.cg.dao.CrudOperations;

public class Main {

	public static void main(String[] args) {
		System.out.println("Hello1");
		CrudOperations crudOperations = new CrudOperations();
		crudOperations.insertEntity();
//		crudOperations.findEntity();
	}
}
