package com.cg.collections;

import java.awt.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.Vector;

public class MapSample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Map <String,String> map=new HashMap<>();
		map.put("FirstName", "Yogendra Singh");
		map.put("LastName", "Rathore");
		Set<String> keys=map.keySet();
		if(keys.contains("LastName"))
			System.out.println("Badiya");
		
		System.out.println(map);
		for(String key: keys)
			System.out.println(key+" "+map.get(key));
		
		Set<Number> java=new HashSet<>();
		java.add(1);
		java.add(3.54f);
		java.add(888.9999);
		java.add(1);
	
		if(java.contains(1))
			System.out.println("Find the number");
		System.out.println(java.remove(1));
		System.out.println(java);
		
		Vector<Number> setter=new Vector<Number>();
		setter.add(1111);
		setter.add(1112);
		setter.add(1115);
		setter.addAll(2, java);
		System.out.println(setter);
		
		
	}

}
