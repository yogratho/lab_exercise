package com.cg.collections;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class IteratorSample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List<Integer> list=new ArrayList<Integer>();
		for(int i=12;i<20;i++)
			list.add(i);
//		Iterator I=list.iterator();
//		while(I.hasNext())
//		{
//			System.out.println(I.next());
//		}
		ListIterator li=list.listIterator();
		while(li.hasPrevious())
		{
			System.out.println(li.previous());
		}
	}

}
