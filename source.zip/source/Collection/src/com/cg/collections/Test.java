package com.cg.collections;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class Test {
	static void methodA(short s) {
	     System.out.println("methodA(short) called");
	    }

	    static void methodA(int i) {
	     System.out.println("methodA(int) called");
	    }
	                         
	                       
	    static void methodB(float f) {
	    System.out.println("methodB(float) called");
	    }

	    static void methodB(double d) {
	    System.out.println("methodB(double) called");
	    }
	      

	public static void main(String [] arsg) {
		// TODO Auto-generated method s
		
             float f=3.25f;
             int a=(int)f;
             byte b1=126;
             byte b2=127;
             byte result=1+0;
             System.out.println(a);
			    methodA((short)256775123);                                                 
			    methodB((int)5.2f);
			    Set ysr=new HashSet();
			    ysr.add(111);
			    ysr.add("sdhasd");
			    ysr.add("sdasda");
			    ysr.add(111);
			    System.out.println(ysr);
			    
	}

}
