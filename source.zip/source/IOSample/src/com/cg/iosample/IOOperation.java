package com.cg.iosample;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
class Test
{
private String name="yogendra";
private String DeptName="JEE";
private int DeptID=231;
private transient double salary=2222222;

}

public class IOOperation {

	public static void main(String[] args) throws IOException {
		File file=new File("D:\\vishalsin\\test.txt");
		FileInputStream fileInputStream=new FileInputStream(file);
		FileOutputStream fileOutputStream =new FileOutputStream("D:\\vishalsin\\testing.txt");
		int display=0;
		while((display=fileInputStream.read())!=-1)
			fileOutputStream.write((char)display);
		
		fileInputStream.close();
		fileOutputStream.close();
		

	}

}
