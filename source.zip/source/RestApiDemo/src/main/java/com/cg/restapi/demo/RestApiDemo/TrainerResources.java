package com.cg.restapi.demo.RestApiDemo;

import javax.ws.rs.Path;

@Path("trainer")
public class TrainerResources {
	
	public Trainer getTrainer() {
	
		Trainer trainer=new Trainer();
		trainer.setTrainerName("Yogendra Singh Rathore");
		trainer.setExperience(5);
	return trainer;
	}
		

}
